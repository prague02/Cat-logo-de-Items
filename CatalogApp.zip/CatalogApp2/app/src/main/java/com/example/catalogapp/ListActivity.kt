package com.example.catalogapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.catalogapp.databinding.ActivityListBinding

class ListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding
    private lateinit var adapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ItemAdapter(ItemsRepository.items.toMutableList(), onDelete = { item ->
            ItemsRepository.remove(item)
            adapter.updateList(ItemsRepository.items)
        })

        binding.rvItems.layoutManager = LinearLayoutManager(this)
        binding.rvItems.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        adapter.updateList(ItemsRepository.items)
    }
}