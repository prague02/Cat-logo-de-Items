package com.example.catalogapp

import java.util.UUID

data class Item(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val imageUrl: String,
    val value: Double
)
