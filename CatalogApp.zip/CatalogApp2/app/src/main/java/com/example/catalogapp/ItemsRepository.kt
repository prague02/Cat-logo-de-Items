package com.example.catalogapp

object ItemsRepository {
    val items = mutableListOf<Item>()

    fun add(item: Item) { items.add(item) }
    fun remove(item: Item) { items.removeAll { it.id == item.id } }
}
