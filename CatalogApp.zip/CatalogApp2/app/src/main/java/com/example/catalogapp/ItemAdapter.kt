package com.example.catalogapp

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.catalogapp.databinding.ItemCardBinding
import coil.load

class ItemAdapter(
    private val list: MutableList<Item>,
    private val onDelete: (Item) -> Unit
) : RecyclerView.Adapter<ItemAdapter.VH>() {

    inner class VH(val binding: ItemCardBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = list[position]
        holder.binding.tvName.text = item.name
        holder.binding.tvValue.text = "R$ ${"%.2f".format(item.value)}"
        holder.binding.imgItem.load(item.imageUrl) {
            placeholder(R.drawable.ic_image_placeholder)
            error(R.drawable.ic_image_placeholder)
        }

        holder.binding.btnEdit.setOnClickListener {
            Toast.makeText(holder.itemView.context, "Editar não implementado", Toast.LENGTH_SHORT).show()
        }

        holder.binding.btnDelete.setOnClickListener {
            onDelete(item)
            Toast.makeText(holder.itemView.context, "Item excluído", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount() = list.size

    fun updateList(newList: List<Item>) {
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}
