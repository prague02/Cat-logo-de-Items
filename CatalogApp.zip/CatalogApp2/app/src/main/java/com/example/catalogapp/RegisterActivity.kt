package com.example.catalogapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.catalogapp.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSave.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            val imageUrl = binding.etImageUrl.text.toString().trim()
            val valueText = binding.etValue.text.toString().trim()

            if (name.isEmpty()) {
                Toast.makeText(this, "Preencha o nome", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val value = valueText.toDoubleOrNull() ?: 0.0

            val item = Item(name = name, imageUrl = imageUrl, value = value)
            ItemsRepository.add(item)
            Toast.makeText(this, "Item adicionado", Toast.LENGTH_SHORT).show()

            // limpa campos
            binding.etName.text?.clear()
            binding.etImageUrl.text?.clear()
            binding.etValue.text?.clear()
        }

        binding.tvViewList.setOnClickListener {
            startActivity(Intent(this, ListActivity::class.java))
        }
    }
}
